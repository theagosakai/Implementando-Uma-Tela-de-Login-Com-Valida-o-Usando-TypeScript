# ProjetoCurso-DIO-React-Desafio4-TelaLogin

Implementando Uma Tela de Login Com Validação Usando TypeScript

DIO Bootcamp Orange tech+

O Orange tech + é um projeto para você que deseja aprender do zero desenvolvimento front-end e back-end e tem o propósito de se preparar de verdade para as melhores vagas do mercado de tecnologia. O primeiro bootcamp do programa será uma trilha gratuita lançada pelo Inter, em parceria com a DIO, que vai abordar desde o princípio as tecnologias JavaScript, HTML, CSS, Typescript e React. Após esse programa, os participantes terão direito a participar de uma trilha completa de back-end. Com foco em alcançar grupos de diversidade como mulheres, pretos e pardos, o Inter disponibilizou 7 mil bolsas de estudos gratuitas. Essa é a sua oportunidade de ter mais visibilidade e impulsionar a representatividade e inclusão no mercado da tecnologia.
